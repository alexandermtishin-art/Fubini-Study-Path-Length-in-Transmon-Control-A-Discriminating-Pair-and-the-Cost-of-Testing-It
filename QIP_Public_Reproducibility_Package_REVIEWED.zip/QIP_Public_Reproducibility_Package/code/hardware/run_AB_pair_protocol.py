"""
run_AB_pair.py — различающий прогон для пары A/B.

Protocol for a future shallow A/B sign-discrimination run.
Session-specific numerical predictions should be generated from the measured calibration
snapshot rather than hard-coded in this execution script.

ЧТО ЗДЕСЬ КРИТИЧНО И ПОЧЕМУ
---------------------------
1. Цепи собираются сразу в базисных гейтах (rz, sx). Обобщённый гейт r() при
   optimization_level >= 1 схлопывается транспилятором в ОДИН гейт x, и эксперимент
   молча превращается в сравнение двух одинаковых цепей. Проверено: без барьеров
   opt=1..3 дают sx=0, x=1 для обеих последовательностей.
2. Барьеры между импульсами обязательны даже для нативной сборки.
3. Твирлинг гейтов и измерений ВЫКЛЮЧЕН. Твирлинг рандомизирует ровно ту когерентную
   структуру, разницу в которой мы меряем.
4. Динамическая развязка ВЫКЛЮЧЕНА. DD меняет саму физику экспозиции к T1.
5. Плечи чередуются блоками внутри ОДНОГО задания. Дрейф калибровки между заданиями
   вошёл бы в разность напрямую.

Виртуальные RZ на сверхпроводниковом железе — смена системы отсчёта: нулевая
длительность, нулевая ошибка. Поэтому A (8 rz) и B (8 rz) имеют одинаковую физическую
длительность при одинаковых 4 импульсах SX. Это надо сказать в тексте статьи явно.
"""

import json
import os
import time
import numpy as np
from qiskit import QuantumCircuit
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2, Batch

# ------------------------------------------------------------------
# Параметры
# ------------------------------------------------------------------
BACKEND_NAME = "ibm_kingston"

# --- Доступ к IBM Quantum -------------------------------------------------
# CRN инстанса не хардкодится: этот файл предназначен для публичного депозита кода.
# Порядок поиска: переменная окружения -> приватный файл рядом со скриптом.
# API-ключ читается ТОЛЬКО из окружения и в файлы не пишется.
# __file__ не определён, если содержимое вставлено в ячейку блокнота — тогда берётся cwd.
try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _HERE = os.getcwd()
INSTANCE_FILE = os.path.join(_HERE, "ibm_instance.local.txt")


def resolve_instance():
    crn = os.environ.get("QISKIT_IBM_INSTANCE")
    if crn:
        return crn.strip()
    if os.path.exists(INSTANCE_FILE):
        for line in open(INSTANCE_FILE, encoding="utf8"):
            line = line.strip()
            if line.startswith("crn:"):
                return line
    raise RuntimeError(
        "Не найден CRN инстанса. Задайте QISKIT_IBM_INSTANCE "
        f"или положите строку crn:... в {INSTANCE_FILE}")


def make_service():
    crn = resolve_instance()
    region = crn.split(":")[5]
    if region != "us-east":
        print(f"ВНИМАНИЕ: регион инстанса {region!r}; Open Plan работает только в us-east.")
    token = os.environ.get("QISKIT_IBM_TOKEN")
    kw = {"channel": "ibm_quantum_platform", "instance": crn}
    if token:
        kw["token"] = token
    return QiskitRuntimeService(**kw)
SHOTS_PER_BLOCK = 4000
BLOCKS_MAIN = 100        # 100 x 4000 = 4.0e5 shots per arm
BLOCKS_EXCHANGE = 20     # только проверка знака: полная статистика требует 2.7e6 на плечо
SEQ = {"A": [270, 0, 0, 270], "B": [180, 0, 0, 0]}


# ------------------------------------------------------------------
# Построение цепей
# ------------------------------------------------------------------
def r_half(qc, phi_deg, q=0):
    """R(pi/2, phi) = RZ(-phi) SX RZ(phi) — один физический импульс."""
    phi = np.deg2rad(phi_deg)
    qc.rz(-phi, q)
    qc.sx(q)
    qc.rz(phi, q)


def make_circuit(seq_name, start_excited):
    qc = QuantumCircuit(1, 1)
    if start_excited:
        qc.x(0)              # обменный контроль: старт с возбуждённого уровня
        qc.barrier(0)
    for phi in SEQ[seq_name]:
        r_half(qc, phi)
        qc.barrier(0)
    qc.measure(0, 0)
    qc.metadata = {"seq": seq_name, "start": "excited" if start_excited else "ground"}
    return qc


def error_from_counts(counts, start_excited):
    """Цель — противоположный стартовому уровень. Ошибка = доля возвратов к старту."""
    n0, n1 = counts.get("0", 0), counts.get("1", 0)
    n = n0 + n1
    wrong = n1 if start_excited else n0     # старт |1> -> цель |0>; старт |0> -> цель |1>
    return wrong / n, n


# ------------------------------------------------------------------
# Выбор кубита и снимок калибровки
# ------------------------------------------------------------------
def pick_qubit_and_snapshot(backend):
    props = backend.properties()
    rows = []
    for q in range(backend.num_qubits):
        try:
            rows.append({
                "qubit": q,
                "T1_us": props.t1(q) * 1e6,
                "T2_us": props.t2(q) * 1e6,
                "sx_error": props.gate_error("sx", q),
                "sx_length_ns": props.gate_length("sx", q) * 1e9,
                "readout_error": props.readout_error(q),
                "p0m1": props.qubit_property(q, "prob_meas0_prep1")[0],
                "p1m0": props.qubit_property(q, "prob_meas1_prep0")[0],
            })
        except Exception:
            continue
    # Ранжирование: длинные времена когерентности, малая ошибка SX, малая ошибка считывания.
    rows.sort(key=lambda r: (r["sx_error"] + r["readout_error"]) / (r["T1_us"] * r["T2_us"]))
    best = rows[0]
    snapshot = {
        "backend": backend.name,
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "properties_last_update": str(props.last_update_date),
        "chosen": best,
        "all_qubits": rows,
    }
    return best["qubit"], snapshot


# ------------------------------------------------------------------
# Основной прогон
# ------------------------------------------------------------------
def main():
    service = make_service()
    backend = service.backend(BACKEND_NAME)
    qubit, snapshot = pick_qubit_and_snapshot(backend)
    print(f"Кубит {qubit}: T1 = {snapshot['chosen']['T1_us']:.1f} мкс, "
          f"T2 = {snapshot['chosen']['T2_us']:.1f} мкс, "
          f"SX {snapshot['chosen']['sx_length_ns']:.1f} нс, "
          f"ошибка считывания {snapshot['chosen']['readout_error']:.4f}")

    # Чередующийся список цепей: A,B,A,B,... в одном задании.
    circuits, tags = [], []
    for _ in range(BLOCKS_MAIN):
        for s in ("A", "B"):
            circuits.append(make_circuit(s, start_excited=False))
            tags.append((s, "ground"))
    for _ in range(BLOCKS_EXCHANGE):
        for s in ("A", "B"):
            circuits.append(make_circuit(s, start_excited=True))
            tags.append((s, "excited"))

    # Транспиляция на выбранный кубит. initial_layout фиксирует кубит;
    # цепи уже в базисе, поэтому уровень оптимизации ничего не схлопнет.
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
    pm = generate_preset_pass_manager(optimization_level=1, backend=backend,
                                      initial_layout=[qubit])
    isa = pm.run(circuits)

    # Санитарная проверка: у каждой цепи ровно 4 импульса SX (плюс 1 X в обменных).
    for c, (s, st) in zip(isa, tags):
        n_sx = c.count_ops().get("sx", 0)
        n_x = c.count_ops().get("x", 0)
        assert n_sx == 4, f"{s}/{st}: sx={n_sx}, ожидалось 4 — транспилятор схлопнул цепь"
        assert n_x == (1 if st == "excited" else 0), f"{s}/{st}: x={n_x}"
    print(f"Проверка пройдена: {len(isa)} цепей, у каждой 4 импульса SX.")

    with Batch(backend=backend):
        sampler = SamplerV2()
        sampler.options.default_shots = SHOTS_PER_BLOCK
        sampler.options.dynamical_decoupling.enable = False      # меняет физику
        sampler.options.twirling.enable_gates = False            # рандомизирует измеряемое
        sampler.options.twirling.enable_measure = False
        job = sampler.run(isa)
        print(f"job id: {job.job_id()}")
        result = job.result()

    # Разбор с сохранением порядка блоков — порядок нужен для теста на дрейф.
    blocks = []
    for i, (res, (s, st)) in enumerate(zip(result, tags)):
        counts = res.data.c.get_counts()
        p, n = error_from_counts(counts, st == "excited")
        blocks.append({"index": i, "seq": s, "start": st, "p_err": p, "shots": n})

    out = {"snapshot": snapshot, "job_id": job.job_id(),
           "shots_per_block": SHOTS_PER_BLOCK, "blocks": blocks}
    with open("AB_run_raw.json", "w") as f:
        json.dump(out, f, indent=2)

    # Сводка
    print(f"\n{'старт':>10}  {'A':>12}  {'B':>12}  {'B/A':>7}  {'B-A':>12}")
    print("-" * 60)
    for st in ("ground", "excited"):
        pa = [b["p_err"] for b in blocks if b["seq"] == "A" and b["start"] == st]
        pb = [b["p_err"] for b in blocks if b["seq"] == "B" and b["start"] == st]
        if not pa:
            continue
        ma, mb = np.mean(pa), np.mean(pb)
        se = np.sqrt(np.var(pa, ddof=1) / len(pa) + np.var(pb, ddof=1) / len(pb))
        print(f"{st:>10}  {ma:12.5e}  {mb:12.5e}  {mb/ma:7.4f}  "
              f"{mb-ma:+12.4e} +- {se:.1e}")
    print("\nCompare the measured signs with a session-specific open-system baseline.")
    print("Сырые данные сохранены в AB_run_raw.json.")


if __name__ == "__main__":
    main()
