import numpy as np

def Rx(theta):
    return np.array([[np.cos(theta/2), -1j*np.sin(theta/2)],
                      [-1j*np.sin(theta/2), np.cos(theta/2)]])
def Ry(theta):
    c,s = np.cos(theta/2), np.sin(theta/2)
    return np.array([[c,-s],[s,c]], dtype=complex)

ket0 = np.array([1,0],dtype=complex)

def fs_length_along_sequence(ops, psi0, n_steps_per_op=2000):
    """numerically integrate the FS path length by finely subdividing each pi/2 rotation"""
    psi = psi0.copy()
    total_l = 0.0
    for (axis, angle) in ops:
        R = Rx if axis=='x' else Ry
        dtheta = angle / n_steps_per_op
        for _ in range(n_steps_per_op):
            psi_next = R(dtheta) @ psi
            # Fubini-Study infinitesimal distance = arccos(|<psi|psi_next>|)
            ov = np.abs(np.vdot(psi, psi_next))
            ov = min(ov, 1.0)
            total_l += np.arccos(ov)
            psi = psi_next
    return total_l, psi

# Path A: R_{-y}(pi/2), R_x(pi/2), R_x(pi/2), R_{-y}(pi/2)  -- applied in time order left-to-right
ops_A = [('y', -np.pi/2), ('x', np.pi/2), ('x', np.pi/2), ('y', -np.pi/2)]
# Path B: R_{-x}(pi/2), R_x(pi/2), R_x(pi/2), R_x(pi/2)
ops_B = [('x', -np.pi/2), ('x', np.pi/2), ('x', np.pi/2), ('x', np.pi/2)]

lA, psiA = fs_length_along_sequence(ops_A, ket0)
lB, psiB = fs_length_along_sequence(ops_B, ket0)
print(f"l_FS^A (numerically integrated) = {lA:.5f}   (claim: pi/2 = {np.pi/2:.5f})")
print(f"l_FS^B (numerically integrated) = {lB:.5f}   (claim: pi     = {np.pi:.5f})")

# T1-exposure integral I_e = integral of P_e(t) dt for each pi/2 pulse segment, resonant Rabi drive
# For a resonant pi/2 pulse starting from |0>: P_e(t) = sin^2(Omega t /2), with Omega*tau = pi/2 over pulse duration tau
# => P_e(t) = sin^2( (pi/2) * (t/tau) / 2 )... let's just integrate properly per-segment based on actual Bloch trajectory.

def excited_pop_trace(ops, psi0, tau=1.0, n_steps_per_op=4000):
    """Integrate P_e(t)=|<1|psi(t)>|^2 along the ACTUAL sequence trajectory (each pulse duration = tau)."""
    psi = psi0.copy()
    Ie = 0.0
    for (axis, angle) in ops:
        R = Rx if axis=='x' else Ry
        dtheta = angle / n_steps_per_op
        dt = tau / n_steps_per_op
        for _ in range(n_steps_per_op):
            Pe = np.abs(psi[1])**2
            Ie += Pe*dt
            psi = R(dtheta) @ psi
    return Ie

IeA = excited_pop_trace(ops_A, ket0)
IeB = excited_pop_trace(ops_B, ket0)
print(f"\nI_e^A (numeric) = {IeA:.5f}   (claim: 2*tau = 2.00000, tau=1)")
print(f"I_e^B (numeric) = {IeB:.5f}   (claim: (2-2/pi)*tau = {2-2/np.pi:.5f})")
