import numpy as np, qutip as qt
sx, sy = qt.sigmax(), qt.sigmay()
psi0 = qt.basis(2,0)

def rotation_H(axis_angle_deg, tau):
    Omega = (np.pi/2) / tau
    phi = np.deg2rad(axis_angle_deg)
    return (Omega/2) * (np.cos(phi)*sx + np.sin(phi)*sy)

def run_noiseless(axis_angles_deg, tau, psi0):
    psi = psi0
    for ang in axis_angles_deg:
        H = rotation_H(ang, tau)
        result = qt.sesolve(H, psi, np.linspace(0,tau,50))
        psi = result.states[-1]
    return psi

seq_A = [270, 0, 0, 270]
seq_B = [180, 0, 0, 0]
tau = 60e-9
psiA = run_noiseless(seq_A, tau, psi0)
psiB = run_noiseless(seq_B, tau, psi0)
target = (-1j*sx)*psi0

print("psi_A (noiseless) =", psiA.full().flatten())
print("psi_B (noiseless) =", psiB.full().flatten())
print("target -i*sx|0>   =", target.full().flatten())
print()
print("fidelity(A,target) =", qt.fidelity(psiA*psiA.dag(), target*target.dag()))
print("fidelity(B,target) =", qt.fidelity(psiB*psiB.dag(), target*target.dag()))
