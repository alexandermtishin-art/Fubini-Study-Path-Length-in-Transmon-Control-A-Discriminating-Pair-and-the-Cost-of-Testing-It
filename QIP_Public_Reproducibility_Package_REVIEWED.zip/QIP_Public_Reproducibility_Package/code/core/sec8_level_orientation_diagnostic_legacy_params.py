"""
sec8_full_lindblad_baseline_CORRECTED.py

Same calculation as the deposited sec8_full_lindblad_baseline.py, with the
level-labelling made explicit and consistent with the relaxation channel.

The issue in the deposited version
----------------------------------
QuTiP's conventions are

    sigmaz() = diag(+1, -1)          basis(2,0) is the +1 eigenstate
    sigmam() = [[0,0],[1,0]]         maps basis(2,0) -> basis(2,1)

so under QuTiP's own convention basis(2,0) is the EXCITED level and
basis(2,1) is the GROUND level: sigma_- depletes basis(2,0).

The deposited script sets

    psi0   = basis(2,0)              -> the excited level
    target = -i sigma_x |0>          -> the ground level
    c_ops  = [sqrt(1/T1) sigma_-]    -> drives basis(2,0) into basis(2,1)

i.e. it starts in the level that relaxes and targets the level it relaxes
into, so amplitude damping pushes the state TOWARDS the target. In a real
single-qubit X gate the qubit is prepared in the ground state and driven to
the excited state, so relaxation pushes AWAY from the target.

The companion script sec6_verify_fs_length.py uses the opposite labelling
(index 1 treated as the excited level, in `excited_pop_trace`). The two
scripts in the deposit therefore disagree with each other about which level
is which; only sec8 feeds the relaxation channel, so only sec8 is affected.

Both consistent repairs are computed below and agree exactly.
"""

import numpy as np
import qutip as qt

T1 = 180e-6
T2 = 120e-6
Tphi = 1.0 / (1.0 / T2 - 1.0 / (2 * T1))

sx, sy, sz = qt.sigmax(), qt.sigmay(), qt.sigmaz()
sm, sp = qt.sigmam(), qt.sigmap()
dephasing = np.sqrt(1.0 / (2.0 * Tphi)) * sz


def rotation_H(axis_angle_deg, tau):
    Omega = (np.pi / 2) / tau
    phi = np.deg2rad(axis_angle_deg)
    return (Omega / 2) * (np.cos(phi) * sx + np.sin(phi) * sy)


def run_sequence(axis_angles_deg, tau, psi0, c_ops, nsteps=200):
    rho = psi0.proj()
    for ang in axis_angles_deg:
        rho = qt.mesolve(rotation_H(ang, tau), rho,
                         np.linspace(0, tau, nsteps), c_ops=c_ops).states[-1]
    return rho


def error_prob(rho, target_ket):
    return 1 - qt.fidelity(rho, target_ket.proj()) ** 2


SEQ_A = [270, 0, 0, 270]     # R_{-y}, R_x, R_x, R_{-y}   l_FS = pi/2
SEQ_B = [180, 0, 0, 0]       # R_{-x}, R_x, R_x, R_x      l_FS = pi

VARIANTS = [
    ("as deposited", qt.basis(2, 0), [np.sqrt(1 / T1) * sm, dephasing],
     "relaxation drives the state INTO the target"),
    ("repair 1", qt.basis(2, 1), [np.sqrt(1 / T1) * sm, dephasing],
     "start in the level sigma_- does not deplete"),
    ("repair 2", qt.basis(2, 0), [np.sqrt(1 / T1) * sp, dephasing],
     "keep the start, point the relaxation channel away from the target"),
]

print(f"T1 = {T1*1e6:.0f} us   T2 = {T2*1e6:.0f} us   Tphi = {Tphi*1e6:.0f} us")
print()
print(f"{'tau':>7}  {'variant':>14}  {'P_err^A':>12}  {'P_err^B':>12}"
      f"  {'B - A':>12}  {'B/A':>7}  ranking vs l_FS")
print("-" * 96)

for tau_ns in (32, 60, 100):
    tau = tau_ns * 1e-9
    for label, psi0, c_ops, _ in VARIANTS:
        target = (-1j * sx) * psi0
        pa = error_prob(run_sequence(SEQ_A, tau, psi0, c_ops), target)
        pb = error_prob(run_sequence(SEQ_B, tau, psi0, c_ops), target)
        verdict = "matches" if pb > pa else "OPPOSITE"
        print(f"{tau_ns:>5}ns  {label:>14}  {pa:12.5e}  {pb:12.5e}"
              f"  {pb-pa:+12.4e}  {pb/pa:7.4f}  {verdict}")
    print()

print("The two repairs agree to all printed digits, and both reverse the")
print("ranking reported in the manuscript: under standard open-system theory")
print("with the relaxation channel oriented as in a real X gate, the LONGER")
print("Fubini-Study path (sequence B) is the LESS error-prone of the two.")
print()

# Required shot count for a hardware test, both variants.
def shots_per_arm(pa, pb, z=3.0):
    p, d = (pa + pb) / 2, abs(pb - pa)
    return 2 * p * (1 - p) * z * z / d ** 2

tau = 60e-9
print("Shots per arm to resolve the predicted difference at 3 sigma (tau = 60 ns):")
for label, psi0, c_ops, _ in VARIANTS:
    target = (-1j * sx) * psi0
    pa = error_prob(run_sequence(SEQ_A, tau, psi0, c_ops), target)
    pb = error_prob(run_sequence(SEQ_B, tau, psi0, c_ops), target)
    print(f"  {label:>14}:  |B-A| = {abs(pb-pa):.3e}"
          f"   n = {shots_per_arm(pa, pb):.2e}")
