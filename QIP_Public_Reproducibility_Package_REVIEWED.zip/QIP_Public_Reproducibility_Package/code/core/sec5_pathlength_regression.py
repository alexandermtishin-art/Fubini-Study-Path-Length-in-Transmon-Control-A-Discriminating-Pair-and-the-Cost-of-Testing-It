"""
Section V: path-length effect on ibm_kingston (156QUB_1.CSV).

Reproduces:
  - nested model comparison: error ~ C(theta) vs error ~ C(theta) + l_FS
    (F(1,98)=152.7, p=1.0e-21)
  - leave-one-family-out sensitivity table (slopes 0.001557-0.001819)
  - diagnosis of why a naive cluster bootstrap over 4 families is uninformative
    (pigeonhole: a "full-diversity" resample of 4 draws from 4 items is just
    the original data in a different row order; degenerate resamples create
    near-collinearity between theta and l_FS within a single protocol)
  - the exact 1:2:2:7 integer-multiple structure of l_FS across the 4 protocols,
    which shows gate/segment count cannot be separated from l_FS in this design

Requires: 156QUB_1.CSV in the same directory (from the IBM Heron r2 campaign,
ibm_kingston, 2026-06-05).
"""
import csv, numpy as np, pandas as pd
import statsmodels.formula.api as smf
from collections import Counter, defaultdict

rows = list(csv.DictReader(open('data/legacy_campaign/156QUB_1.CSV')))
df = pd.DataFrame([{'protocol': r['protocol'], 'theta': float(r['theta']),
                     'l_FS': float(r['l_FS_path']),
                     'err': float(r['P1_error_after_inverse'])} for r in rows])
df['theta_cat'] = df['theta'].astype(str)

print("=== 1:2:2:7 structure (gate-count/l_FS collinearity) ===")
for p in df['protocol'].unique():
    sub = df[(df['protocol'] == p) & (np.isclose(df['theta'], np.pi))]
    l = sub['l_FS'].iloc[0]
    print(f"  {p:22s} l_FS(theta=pi) = {l:.4f}  (x{l/(np.pi/2):.2f} of geodesic)")

print("\n=== Nested model comparison (Sec. V, Fig. 1) ===")
mA = smf.ols('err ~ C(theta_cat)', data=df).fit()
mB = smf.ols('err ~ C(theta_cat) + l_FS', data=df).fit()
print(f"  Model A (theta only, 9-level fixed effect): R^2 = {mA.rsquared:.4f}")
print(f"  Model B (theta + l_FS):                     R^2 = {mB.rsquared:.4f}")
print(f"  l_FS coefficient = {mB.params['l_FS']:.6f}")
from statsmodels.stats.anova import anova_lm
comp = anova_lm(mA, mB)
print(comp)

print("\n=== Leave-one-family-out sensitivity ===")
for g in df['protocol'].unique():
    sub = df[df['protocol'] != g]
    m = smf.ols('err ~ C(theta_cat) + l_FS', data=sub).fit()
    print(f"  excluding {g:22s}: slope = {m.params['l_FS']:.6f}")
print(f"  full sample:                          slope = {mB.params['l_FS']:.6f}")

print("\n=== Shot-level bootstrap CI (within protocol x theta cells) ===")
rng = np.random.default_rng(42)
cells = defaultdict(list)
data = list(zip(df['protocol'], df['theta'], df['l_FS'], df['err']))
for proto, th, l, e in data:
    cells[(proto, th)].append(e)
lmap = {}
for proto, th, l, e in data:
    lmap[(proto, th)] = l
slopes = []
for _ in range(5000):
    boot = []
    for (proto, th), errs in cells.items():
        idx = rng.integers(0, len(errs), size=len(errs))
        for i in idx:
            boot.append((th, lmap[(proto, th)], errs[i]))
    by_theta = defaultdict(list)
    for th, l, e in boot:
        by_theta[th].append((l, e))
    rl, re_ = [], []
    for th, items in by_theta.items():
        me = np.mean([e for _, e in items])
        for l, e in items:
            rl.append(l); re_.append(e - me)
    rl, re_ = np.array(rl), np.array(re_)
    A = np.vstack([rl, np.ones_like(rl)]).T
    b, a = np.linalg.lstsq(A, re_, rcond=None)[0]
    slopes.append(b)
slopes = np.array(slopes)
lo, hi = np.percentile(slopes, [2.5, 97.5])
print(f"  slope = {np.median(slopes):.6f}, 95% CI (shot-level only) = [{lo:.6f}, {hi:.6f}]")

print("\n=== Why a naive 4-cluster bootstrap is uninformative (diagnostic) ===")
protocols = df['protocol'].unique()
n_unique_dist = Counter()
for _ in range(5000):
    chosen = rng.choice(protocols, size=len(protocols), replace=True)
    n_unique_dist[len(set(chosen))] += 1
print("  distribution of unique protocols per 4-draw resample:")
for k in sorted(n_unique_dist):
    print(f"    {k} unique: {n_unique_dist[k]} resamples ({100*n_unique_dist[k]/5000:.1f}%)")
print("  NOTE: a resample with all 4 unique protocols is, by the pigeonhole")
print("  principle, necessarily each protocol exactly once -- i.e. the original")
print("  dataset in a different row order. Since OLS is row-order invariant,")
print("  such resamples give zero spread by construction, not as a finding.")
print("  This is why leave-one-out (above), not cluster bootstrap, is used.")
