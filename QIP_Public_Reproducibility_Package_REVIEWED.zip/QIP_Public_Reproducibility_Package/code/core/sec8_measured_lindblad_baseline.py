"""Reproduce the Sec. 8 Lindblad ranking using measured device parameters.

Model: two-level transmon, piecewise-constant pi/2 drives, amplitude damping and
pure dephasing. The physical convention is |0>=ground, |1>=excited, with
relaxation |1> -> |0>. Native pulse duration tau = 32 ns.

The listed T1/T2 values are the five candidate-qubit values reported in the
manuscript / Appendix A. The exact matrix-exponential implementation below
avoids time-discretization error; tiny differences from printed manuscript
values reflect the manuscript solver's finite integration grid.
"""
import numpy as np
from scipy.linalg import expm

SX = np.array([[0, 1], [1, 0]], dtype=complex)
SY = np.array([[0, -1j], [1j, 0]], dtype=complex)
SZ = np.diag([1, -1]).astype(complex)
LOWER = np.array([[0, 1], [0, 0]], dtype=complex)  # |0><1|
I2 = np.eye(2, dtype=complex)

SEQ_A = [270, 0, 0, 270]
SEQ_B = [180, 0, 0, 0]
TAU = 32e-9
CANDIDATES = [
    (141, 368.9e-6, 226.7e-6),
    (21,  319.3e-6, 328.9e-6),
    (149, 347.2e-6, 355.8e-6),
    (140, 287.6e-6, 483.0e-6),
    (95,  398.1e-6, 512.1e-6),
]

def liouvillian(H, collapse_ops):
    L = -1j * (np.kron(I2, H) - np.kron(H.T, I2))
    for c in collapse_ops:
        cdc = c.conj().T @ c
        L += np.kron(c.conj(), c)
        L -= 0.5 * np.kron(I2, cdc)
        L -= 0.5 * np.kron(cdc.T, I2)
    return L

def h_drive(phi_deg):
    phi = np.deg2rad(phi_deg)
    omega = (np.pi / 2) / TAU
    return (omega / 2) * (np.cos(phi) * SX + np.sin(phi) * SY)

def run(seq, T1, T2):
    Tphi = 1.0 / (1.0 / T2 - 1.0 / (2.0 * T1))
    cops = [np.sqrt(1.0 / T1) * LOWER,
            np.sqrt(1.0 / (2.0 * Tphi)) * SZ]
    rho = np.array([[1, 0], [0, 0]], dtype=complex)  # ground state
    for phi in seq:
        prop = expm(liouvillian(h_drive(phi), cops) * TAU)
        rho = (prop @ rho.reshape(-1, order="F")).reshape((2, 2), order="F")
    return float(1.0 - rho[1, 1].real)  # target after X is |1>

if __name__ == "__main__":
    print("qubit   T1_us   T2_us      P_err(A)      P_err(B)      B/A")
    for q, T1, T2 in CANDIDATES:
        pa = run(SEQ_A, T1, T2)
        pb = run(SEQ_B, T1, T2)
        print(f"{q:5d}  {T1*1e6:6.1f}  {T2*1e6:6.1f}   {pa:11.4e}   {pb:11.4e}   {pb/pa:7.4f}")
