import numpy as np

def Rx(theta):
    return np.array([[np.cos(theta/2), -1j*np.sin(theta/2)],
                      [-1j*np.sin(theta/2), np.cos(theta/2)]])
def Ry(theta):
    c,s = np.cos(theta/2), np.sin(theta/2)
    return np.array([[c,-s],[s,c]])

# Sequences as given (matrix multiplication: apply rightmost first, standard convention)
Rmy = Ry(-np.pi/2)
Rxp = Rx(np.pi/2)

U_A = Rmy @ Rxp @ Rxp @ Rmy
U_B = Rxp @ Rxp @ Rxp @ Rx(-np.pi/2)   # R_{-x}(pi/2) applied first (rightmost)

def show(name, U):
    # normalize global phase for comparison to -i*sigma_x
    print(f"{name} =\n{np.round(U,4)}")

show("U_A", U_A)
show("U_B", U_B)

target = -1j*np.array([[0,1],[1,0]])
print("\ntarget -i*sigma_x =\n", target)

def global_phase_equal(U, target, tol=1e-6):
    # find if U = e^{i phi} * target
    ratios = U[np.abs(target)>1e-9] / target[np.abs(target)>1e-9]
    return np.allclose(ratios, ratios[0], atol=tol), ratios[0] if len(ratios) else None

eqA, phA = global_phase_equal(U_A, target)
eqB, phB = global_phase_equal(U_B, target)
print("\nU_A == target up to global phase:", eqA, " phase=", phA)
print("U_B == target up to global phase:", eqB, " phase=", phB)
