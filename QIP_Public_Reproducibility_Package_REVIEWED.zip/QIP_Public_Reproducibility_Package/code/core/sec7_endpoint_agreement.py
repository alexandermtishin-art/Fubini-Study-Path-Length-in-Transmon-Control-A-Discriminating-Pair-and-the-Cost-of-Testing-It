"""
Section VII: endpoint agreement across three backends (156QUB_3.CSV).

Reproduces:
  - the 0.011 spread among 3 paths x 3 backends sharing the same endpoint
  - verification that this spread equals the Born-rule-corrected residual
    spread exactly (since sin^2(d_FS) is a common constant for all 9 points)
  - the 9 within-backend pairwise differences, each expressed in units of
    shot noise (binomial standard error), for both 1024- and 2048-shot
    assumptions (the source file does not log a per-row shot count)
"""
import csv, numpy as np

rows = list(csv.DictReader(open('data/legacy_campaign/156QUB_3.CSV')))
data = [(r['backend'], r['protocol'], float(r['d_FS']), float(r['P1'])) for r in rows]

same_d = [r for r in data if abs(r[2] - 0.7853981633974484) < 1e-6]
print("=== 3 paths x 3 backends sharing the same endpoint (d_FS=pi/4) ===")
for b, p, d, p1 in same_d:
    print(f"  {b:15s} {p:12s} P1={p1:.5f}")
p1s = [r[3] for r in same_d]
print(f"  spread = {max(p1s)-min(p1s):.4f}")

# Born-rule residual check: subtracting a common constant does not change the spread
resid = [p1 - np.sin(d)**2 for _, _, d, p1 in same_d]
print(f"  Born-corrected residual spread = {max(resid)-min(resid):.4f}  (identical, as expected)")

print("\n=== within-backend pairwise differences, in units of shot noise ===")
from collections import defaultdict
by_backend = defaultdict(dict)
for b, p, d, p1 in same_d:
    by_backend[b][p] = p1

for n_shots in (1024, 2048):
    se_diff = np.sqrt(2*0.5*0.5/n_shots)
    print(f"\n  assuming {n_shots} shots (pairwise SE={se_diff:.5f}):")
    sigmas = []
    for be, vals in by_backend.items():
        names = list(vals)
        for i in range(len(names)):
            for j in range(i+1, len(names)):
                d_ = vals[names[i]] - vals[names[j]]
                sig = abs(d_) / se_diff
                sigmas.append(sig)
                print(f"    {be:15s} {names[i]:8s}-{names[j]:8s}: dP={d_:+.5f}  {sig:.2f} sigma")
    print(f"  max = {max(sigmas):.3f} sigma, mean = {np.mean(sigmas):.3f} sigma")
    print(f"  (coarser check) overall range 0.011 / SE = {0.011/se_diff:.3f}")
