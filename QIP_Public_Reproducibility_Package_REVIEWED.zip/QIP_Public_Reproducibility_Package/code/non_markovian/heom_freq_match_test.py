"""Test whether HEOM's earlier coupling-insensitivity was a real numerical
bug, or simply the physical fact that bath frequencies far below the
anharmonicity (1e5-1e8 Hz vs 1.88e9 rad/s) cannot couple to level
dynamics. Rerun with bath frequencies comparable to the anharmonicity.
"""
import numpy as np
import qutip as qt
from qutip.solver.heom import BosonicBath, HEOMSolver
import warnings
warnings.filterwarnings('ignore')

TAU = 32e-9
OMEGA = (np.pi/2) / TAU
ALPHA_ANHARM = 2*np.pi*(-300e6)  # rad/s, ~ -1.88e9
SEQ = {"A": [270, 0, 0, 270], "B": [180, 0, 0, 0]}

b = np.array([[0,1,0],[0,0,np.sqrt(2)],[0,0,0]], dtype=complex)
bdag = b.conj().T
n_op = qt.Qobj(np.diag([0,1,2]).astype(complex))
H_free = ALPHA_ANHARM/2 * (n_op * (n_op - qt.qeye(3)))

def H_pulse(phi_deg):
    phi = np.deg2rad(phi_deg)
    return H_free + (OMEGA/2)*(np.exp(1j*phi)*qt.Qobj(b) + np.exp(-1j*phi)*qt.Qobj(bdag))

_pulse_cache = {}
def get_pulse(phi):
    if phi not in _pulse_cache:
        _pulse_cache[phi] = H_pulse(phi)
    return _pulse_cache[phi]

MAX_DEPTH = 4
OPTS = {"progress_bar": False, "nsteps": 20000, "method": "bdf",
        "atol": 1e-10, "rtol": 1e-8}

def make_bath(kappa, f_lo, f_hi, n_modes=4):
    vk = np.geomspace(f_lo, f_hi, n_modes) * 2*np.pi
    ck_real = [kappa*v for v in vk]
    return BosonicBath(n_op, ck_real, list(vk), [], [])

def run(name, k, bath):
    phis = SEQ[name]*k
    n_pulses = len(phis)
    ops = [get_pulse(p) for p in phis]
    def H_t(t, args=None):
        idx = min(int(t/TAU), n_pulses-1)
        return ops[idx]
    solver = HEOMSolver(qt.QobjEvo(H_t), bath, max_depth=MAX_DEPTH, options=OPTS)
    rho0 = qt.ket2dm(qt.basis(3,0))
    tlist = np.arange(0, n_pulses+1)*TAU
    result = solver.run(rho0, tlist)
    rho = result.states[-1]
    return np.real(rho[0,0]), np.real(rho[1,1]), np.real(rho[2,2])

print("Bath frequencies NEAR the anharmonicity scale (1e8 - 3e9 Hz):")
for kappa in [1e-4, 1e-3, 1e-2]:
    bath = make_bath(kappa, 1e8, 3e9)
    p0,p1,p2 = run("A", 2, bath)
    print(f"  kappa={kappa:.0e}: p0={p0:.5f} p1={p1:.5f} p2={p2:.5f}")
