# HEOM coupling-insensitivity: resolved

The earlier "blocked" HEOM finding (complete insensitivity of the qutrit
calculation to bath coupling strength kappa) was traced to its real cause:
it is genuine physics, not a numerical bug.

Root cause: the ratio alpha/Omega (anharmonicity / Rabi rate) determines
how strongly a pure dephasing (number-operator-coupled) bath can affect
POPULATION-based quantities like leakage. Scanning this ratio at a safe
O(1) numerical scale (heom_freq_match_test.py and the follow-up ratio scan)
shows coupling sensitivity dropping sharply as alpha/Omega grows past ~20-40.
The real device sits at alpha/Omega ~ 38.4 -- squarely in the
insensitive regime. This is consistent with, not contradictory to, the
earlier finding (mechanism 5/6) that amplitude-coupled noise (not
dephasing-coupled) was needed to get any traction on the anomaly, and with
TEMPO (B.4d) only working because its cutoff was comparable to, not far
below, the anharmonicity scale.

Status change: HEOM mechanism moves from "blocked" to "rejected on
physical grounds" -- joining mechanisms 1-11 as a definitively closed
(not open) direction.
