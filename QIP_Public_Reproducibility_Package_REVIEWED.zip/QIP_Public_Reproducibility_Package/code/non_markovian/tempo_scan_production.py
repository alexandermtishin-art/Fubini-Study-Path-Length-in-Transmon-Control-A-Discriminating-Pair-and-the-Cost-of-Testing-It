"""
TEMPO non-Markovian scan for the repetition-scan anomaly (Sec. XI /
Appendix B.4d of Flagship_Draft). Run in Google Colab.

WHAT THIS DOES
---------------
Scans (alpha, zeta, cutoff, dkmax) for the qutrit A/B pulse-sequence model
under an Ohmic-family PowerLawSD bath, computed with OQuPy's process-tensor
TEMPO method, looking for a parameter point that reproduces BOTH the
measured B/A(k) curve's shape (including the k=20-30 dip already matched at
cutoff=1.2) AND its continued growth out to k=60 (which cutoff=1.2 failed
to sustain -- see Appendix B, section B.4d). The grid deliberately extends
to longer bath memory (smaller cutoff) and larger dkmax than tried so far,
because k=45-60 spans ~5.8-7.7 microseconds and a bath/TEMPO memory window
much shorter than that cannot physically show growth all the way out.

CHECKPOINTING / CRASH SAFETY -- READ THIS, IT IS NOT ABSOLUTE
----------------------------------------------------------------
Two independent, honest layers, not a magic "nothing is ever lost":

1. GRID-LEVEL RESUME (fully reliable). Every fully-completed (alpha, zeta,
   cutoff, dkmax) config is appended as one line to RESULTS_FILE on Drive.
   On (re)start, the script loads this file and skips any config already
   there. So progress across FINISHED configs survives any crash, kernel
   restart, or Colab disconnect -- just re-run this same cell.

2. INTRA-CONFIG PARTIAL CHECKPOINTS (best-effort, bounded loss). Within one
   config's computation (which can take a while at large dkmax / small
   cutoff), progress is saved to PARTIAL_FILE roughly every
   CHECKPOINT_SECONDS (default 12 minutes) of wall-clock time, using
   OQuPy's Tempo.compute(end_time=...) called repeatedly on the SAME live
   object (this is well-defined and supported -- it extends the same
   tensor network rather than restarting). These partial records are for
   your own inspection/diagnosis only.
   IMPORTANT LIMITATION: OQuPy's process tensor / tensor-network internal
   state cannot be serialized and reloaded from disk (checked directly --
   FileProcessTensor only supports 'read' / 'write' (exclusive-create) /
   'overwrite', no append-and-continue). So if the Python process itself
   dies mid-config (not just an exception, an actual kernel crash or
   disconnect), that ONE in-progress config is re-run from scratch on
   restart -- you lose at most the current config's compute time up to
   its last completed CHUNK, not the whole scan. Configs are ordered
   cheapest-first in the grid below so that a crash during a long,
   expensive config does not also cost you the cheap ones -- those will
   already be in RESULTS_FILE.

USAGE
-----
1. Edit DRIVE_DIR below if you want a different folder.
2. Run this cell. It mounts Drive, then works through GRID top to bottom.
3. If Colab disconnects: reconnect, re-run this exact cell. It resumes.
4. Inspect DRIVE_DIR/tempo_scan_results.jsonl at any time (even while the
   scan is still running in another session) for completed configs.

Dependencies: pip install oqupy
"""

# ============================== SETUP ==============================
from google.colab import drive
drive.mount('/content/drive')

import os
DRIVE_DIR = '/content/drive/MyDrive/AMT_flagship/tempo_scan'
os.makedirs(DRIVE_DIR, exist_ok=True)

RESULTS_FILE = os.path.join(DRIVE_DIR, 'tempo_scan_results.jsonl')
PARTIAL_FILE = os.path.join(DRIVE_DIR, 'tempo_scan_partial.jsonl')
LOG_FILE     = os.path.join(DRIVE_DIR, 'tempo_scan_log.txt')

CHECKPOINT_SECONDS = 12 * 60   # save a partial checkpoint at least this often
CHUNK_PULSES = 8               # advance this many pulses per compute() call
                                # before checking the checkpoint clock

import json, time, datetime
import numpy as np
import oqupy
import warnings
warnings.filterwarnings('ignore')


def log(msg):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')


# ============================ PHYSICS ============================
# Same construction as Appendix B.4d, validated there: k=1 propagators
# for both sequences reproduce the exact target unitary of Table A2.

TAU = 32.0                       # ns, measured native SX duration
OMEGA = (np.pi / 2) / TAU        # rad/ns
ALPHA_ANHARM = 2 * np.pi * (-0.3)  # rad/ns, representative -300 MHz anharmonicity
SEQ = {"A": [270, 0, 0, 270], "B": [180, 0, 0, 0]}

_b = np.array([[0, 1, 0], [0, 0, np.sqrt(2)], [0, 0, 0]], dtype=complex)
_bdag = _b.conj().T
n_op = np.diag([0, 1, 2]).astype(complex)
H_free = ALPHA_ANHARM / 2 * (n_op @ (n_op - np.eye(3)))

_pulse_cache = {}
def get_pulse_H(phi_deg):
    if phi_deg not in _pulse_cache:
        phi = np.deg2rad(phi_deg)
        _pulse_cache[phi_deg] = H_free + (OMEGA / 2) * (
            np.exp(1j * phi) * _b + np.exp(-1j * phi) * _bdag)
    return _pulse_cache[phi_deg]

def make_H_of_t(phis):
    ops = [get_pulse_H(p) for p in phis]
    n_pulses = len(phis)
    def H_t(t):
        idx = min(int(t / TAU), n_pulses - 1)
        return ops[idx]
    return H_t

TARGET_KS = [2, 4, 6, 8, 12, 16, 20, 30, 45, 60]
MEASURED = {2: 0.628, 4: 1.064, 6: 1.152, 8: 1.406, 12: 1.621, 16: 1.812,
            20: 1.844, 30: 1.722, 45: 2.189, 60: 2.811}
MAX_K = 60


# ======================= CHECKPOINTED RUN ========================

def load_completed():
    done = set()
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                    done.add((r['alpha'], r['zeta'], r['cutoff'], r['dkmax']))
                except Exception:
                    pass
    return done

def save_jsonl(path, record):
    with open(path, 'a') as f:
        f.write(json.dumps(record) + '\n')
        f.flush()
        os.fsync(f.fileno())


def run_sequence_checkpointed(name, alpha_c, zeta, cutoff, dkmax, config_tag):
    """Runs one sequence (A or B) to MAX_K, saving a partial checkpoint to
    Drive at least every CHECKPOINT_SECONDS of wall-clock time. Returns a
    dict {k: (p0, p1)} for every k in TARGET_KS reached."""
    phis = SEQ[name] * MAX_K
    n_pulses = len(phis)

    system = oqupy.TimeDependentSystem(make_H_of_t(phis))
    correlations = oqupy.PowerLawSD(alpha=alpha_c, zeta=zeta, cutoff=cutoff,
                                     cutoff_type='gaussian', temperature=0.0)
    bath = oqupy.Bath(n_op, correlations)
    rho0 = np.zeros((3, 3), dtype=complex)
    rho0[0, 0] = 1.0
    params = oqupy.TempoParameters(dt=TAU, epsrel=1e-4, dkmax=dkmax)

    tempo = oqupy.Tempo(system=system, bath=bath, parameters=params,
                         initial_state=rho0, start_time=0.0)

    last_checkpoint = time.time()
    current_pulse = 0
    while current_pulse < n_pulses:
        current_pulse = min(current_pulse + CHUNK_PULSES, n_pulses)
        et = current_pulse * TAU
        tempo.compute(end_time=et, progress_type='silent')

        now = time.time()
        is_last = (current_pulse == n_pulses)
        if (now - last_checkpoint >= CHECKPOINT_SECONDS) or is_last:
            dyn = tempo.get_dynamics()
            _, p0_arr = dyn.expectations(np.diag([1, 0, 0]).astype(complex), real=True)
            _, p1_arr = dyn.expectations(np.diag([0, 1, 0]).astype(complex), real=True)
            reached_k = current_pulse // 4
            save_jsonl(PARTIAL_FILE, {
                'config': config_tag, 'seq': name,
                'alpha': alpha_c, 'zeta': zeta, 'cutoff': cutoff, 'dkmax': dkmax,
                'reached_pulse': current_pulse, 'reached_k': reached_k,
                'p0_last': float(p0_arr[-1]), 'p1_last': float(p1_arr[-1]),
                'timestamp': datetime.datetime.now().isoformat(),
            })
            log(f'  [{config_tag}/{name}] checkpoint: pulse {current_pulse}/{n_pulses}'
                f' (k={reached_k}), p0={p0_arr[-1]:.4f} p1={p1_arr[-1]:.4f}')
            last_checkpoint = now

    dyn = tempo.get_dynamics()
    _, p0_arr = dyn.expectations(np.diag([1, 0, 0]).astype(complex), real=True)
    _, p1_arr = dyn.expectations(np.diag([0, 1, 0]).astype(complex), real=True)
    out = {}
    for k in TARGET_KS:
        if k <= MAX_K:
            idx = k * 4
            out[k] = (float(p0_arr[idx]), float(p1_arr[idx]))
    return out


def score(res_A, res_B):
    ks_avail = sorted(set(res_A) & set(res_B))
    ratios = {}
    for k in ks_avail:
        p0a, p1a = res_A[k]
        p0b, p1b = res_B[k]
        target_excited = (k % 2 == 1)
        ea = (1 - p1a) if target_excited else (1 - p0a)
        eb = (1 - p1b) if target_excited else (1 - p0b)
        ratios[k] = eb / ea if ea > 1e-12 else float('nan')
    meas = np.array([MEASURED[k] for k in ks_avail])
    mod = np.array([ratios[k] for k in ks_avail])
    mask = np.isfinite(mod) & (mod > 0)
    logmse = (float(np.mean((np.log(mod[mask]) - np.log(meas[mask])) ** 2))
              if mask.sum() == len(ks_avail) else None)
    return ratios, logmse


# ============================== GRID ==============================
# Ordered cheapest-first (small dkmax / large cutoff) to largest-last, so
# a crash during an expensive late config never costs you the earlier,
# already-saved cheap ones. alpha fixed near the earlier optimum (5e-3);
# the new dimensions being explored are cutoff (bath memory time) and
# dkmax (TEMPO's own explicit memory window) -- both need to grow together
# to have a chance of sustaining the anomaly's growth out to k=60.

GRID = [
    # (alpha, zeta, cutoff, dkmax)
    (5e-3, 1.0, 1.2,  15),   # known point, B.4d baseline (sanity check)
    (5e-3, 1.0, 0.6,  30),
    (5e-3, 1.0, 0.3,  30),
    (5e-3, 1.0, 0.3,  60),
    (5e-3, 0.7, 0.3,  60),
    (5e-3, 1.0, 0.15, 60),
    (5e-3, 1.0, 0.15, 100),
    (5e-3, 0.7, 0.15, 100),
    (7e-3, 1.0, 0.15, 100),
    (5e-3, 1.0, 0.08, 150),
    (5e-3, 0.7, 0.08, 150),
]

done = load_completed()
log(f'=== TEMPO scan starting/resuming ===')
log(f'{len(done)} configs already completed, {len(GRID) - len(done)} remaining')

for alpha_c, zeta, cutoff, dkmax in GRID:
    key = (alpha_c, zeta, cutoff, dkmax)
    if key in done:
        log(f'SKIP (already done): alpha={alpha_c:.0e} zeta={zeta} cutoff={cutoff} dkmax={dkmax}')
        continue

    config_tag = f'a{alpha_c:.0e}_z{zeta}_c{cutoff}_dk{dkmax}'
    log(f'START config {config_tag}')
    t0 = time.time()
    try:
        res_A = run_sequence_checkpointed('A', alpha_c, zeta, cutoff, dkmax, config_tag)
        res_B = run_sequence_checkpointed('B', alpha_c, zeta, cutoff, dkmax, config_tag)
        ratios, logmse = score(res_A, res_B)
        record = {
            'alpha': alpha_c, 'zeta': zeta, 'cutoff': cutoff, 'dkmax': dkmax,
            'ratios': ratios, 'logmse': logmse,
            'elapsed_s': time.time() - t0,
            'timestamp': datetime.datetime.now().isoformat(),
        }
        save_jsonl(RESULTS_FILE, record)
        ratio60 = ratios.get(60)
        ratio60_str = f'{ratio60:.3f}' if ratio60 is not None else 'n/a'
        log(f'DONE config {config_tag}: logMSE={logmse} '
            f'ratio(60)={ratio60_str} elapsed={time.time()-t0:.1f}s')
    except Exception as e:
        log(f'ERROR in config {config_tag}: {type(e).__name__}: {e}  '
            f'(will be retried from scratch on next run -- partial '
            f'checkpoints up to the point of failure are in {PARTIAL_FILE})')
        continue

log('=== Scan pass complete (all grid points attempted or already done) ===')
log(f'Results: {RESULTS_FILE}')
log(f'Partial checkpoints: {PARTIAL_FILE}')
