import numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import csv, pandas as pd
import statsmodels.formula.api as smf
BLUE, ORANGE, GREY, CLOUD = "#0072B2", "#D55E00", "#4D4D4D", "#7FB3D5"
plt.rcParams.update({"font.family":"serif","font.size":11,"axes.linewidth":0.9})

rows=list(csv.DictReader(open('data/156QUB_1.CSV')))
df=pd.DataFrame([{'protocol':r['protocol'],'theta':float(r['theta']),
                   'l_FS':float(r['l_FS_path']),'err':float(r['P1_error_after_inverse'])} for r in rows])
df['theta_cat']=df['theta'].astype(str)
mA = smf.ols('err ~ C(theta_cat)', data=df).fit()
mB = smf.ols('err ~ C(theta_cat) + l_FS', data=df).fit()
b = mB.params['l_FS']
df['resid_display'] = mA.resid + df['err'].mean()

fig, ax = plt.subplots(figsize=(5.6,4.2))
ax.scatter(df['l_FS'], df['resid_display'], s=14, color=CLOUD, alpha=0.65, edgecolor=BLUE, linewidth=0.3, zorder=3)
x=np.linspace(df['l_FS'].min(), df['l_FS'].max(), 50)
a_disp = df['resid_display'].mean() - b*df['l_FS'].mean()
ax.plot(x, a_disp + b*x, '-', color=ORANGE, lw=2.0, zorder=4)
ax.set_xlabel(r'Fubini–Study path length $\ell_{\rm FS}$ (rad)')
ax.set_ylabel(r'round-trip error, adjusted for categorical $\theta$ effect'+'\n'+r'(overall mean retained, not zero-centered)')
ax.tick_params(direction='in', top=True, right=True)
fig.tight_layout(); fig.savefig('fig1_pathcost.png', dpi=300, facecolor='white')
print("ok")
