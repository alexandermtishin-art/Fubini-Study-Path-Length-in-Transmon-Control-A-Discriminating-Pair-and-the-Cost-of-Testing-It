# Reproducibility package
## Fubini–Study Path Length in Transmon Control: A Discriminating Pair and the Cost of Testing It

This archive accompanies the manuscript and its two supplementary appendices.
It collects the calculation scripts and hardware-result records supplied for
public deposition. It is organized so that a reader can distinguish the
original June campaign, the August hardware campaign, the corrected open-system
baseline, and the later non-Markovian mechanism search.

## Contents

- `supplementary/`
  - `ESM_1_Appendix_A_Hardware_Records_QIP.pdf`: hardware records, device metadata,
    job identifiers, circuit construction and measurement protocol.
  - `ESM_2_Appendix_B_Mechanism_Search_QIP.pdf`: systematic mechanism search for
    the repetition-scan anomaly.
- `code/core/`: Secs. 5–8 analysis and verification scripts.
  - `sec8_measured_lindblad_baseline.py` is the current measured-parameter baseline.
  - `sec8_level_orientation_diagnostic_legacy_params.py` is retained only as a
    diagnostic documenting the level-labelling correction; it uses legacy T1/T2
    parameters and is not the manuscript's final numerical baseline.
- `code/hardware/`: cleaned protocol for a future shallow A/B sign-discrimination run.
  No credentials or IBM instance identifiers are embedded.
- `code/non_markovian/`: HEOM resolution test and the production TEMPO scan used
  for the Appendix B non-Markovian follow-up.
- `data/legacy_campaign/`: CSV inputs used by the Sec. 5 / Sec. 7 scripts.
- `data/hardware/`: August 2026 hardware results and run specifications. Duplicate
  uploads were removed; job IDs are retained so records can be independently traced.
- `outputs/`: deposited figure output from the original analysis.

## Security / provenance note

No API tokens, passwords, IBM Cloud API keys, or private credential files are
included. The interactive working notebook is intentionally excluded because it
contains account-specific IBM instance identifiers and exploratory state that is
not required to reproduce the reported calculations.

## Important version note

The earlier deposited Sec. 8 script had the relaxation channel oriented
inconsistently with the physical ground-to-excited X-gate experiment. The
superseded script is intentionally not included as an executable baseline.
The current baseline is `code/core/sec8_measured_lindblad_baseline.py`; the
legacy-parameter diagnostic is included solely to make the correction auditable.

## Hardware data map

The JSON filenames are normalized for readability. Their internal `job_id`
fields are unchanged. Appendix A is the authoritative table mapping job IDs to
purpose, date, qubit, shots and charged processor time.

## Environment

Install the dependencies with:

```bash
pip install -r requirements.txt
```

The core current Lindblad baseline requires only NumPy and SciPy. The legacy
Sec. 8 diagnostic requires QuTiP. Hardware execution scripts require Qiskit and
`qiskit-ibm-runtime`. The TEMPO scan requires OQuPy.

## Credentials

For a new IBM Quantum execution, provide credentials through environment
variables (for example `QISKIT_IBM_TOKEN` and `QISKIT_IBM_INSTANCE`). Never
commit credentials to a public repository.

## Reproduction status

The archive reproduces the supplied core analyses, pulse-pair checks, hardware
records, measured-parameter Lindblad baseline, and the supplied HEOM/TEMPO
follow-up. Appendix B documents a broader mechanism search; only the mechanism
scripts supplied with the final materials are included here. The appendix itself
is the complete narrative audit of that search.
